    // A $( document ).ready() block.
    $( document ).ready(function() {
        console.log( "Pronto para detonar!" );
        larguraTela = $(window).width();
        alturaTela = $(window).height();

        //INICIA O JOGO
        sortLetter(); 
        
        $( "#searchBtn" ).click(function() {
            search();
        });

        //forçando form nao submitar com enter
        location.href = "?#";

        document.onkeydown=function(){
            if(window.event.keyCode=='13'){
                search();
            }
        }    
        
        $('#myModal').modal("show");

    });


    // palavra digitada ou clicada
    var word = ""

    // palavras no jogo
    var words = [("joao"),("matheus"), ("thiago"),("clara")];

    // letras de cada palavra
    var correctLetters = [['j','o','a','o'],['m','a','t','h','e','u','s'], ['t','h','i','a','g','o'], ['c','l','a','r','a']];

    // posicao de cada letra na matriz
    var correctWordsPositions = [ [0,10,20,30],[3,4,5,6,7,8,9], [57,56,55,54,53,52], [95,86,77,68,59]   ];
                                                                //[37,36,35,34,33,32]
                                                                //[32,33,34,35,36,37]
                                                                //passando a ultima palara invertida
    var totalWords = 0;

    var word1 = false;
    var word2 = false;
    var word3 = false;    
    var word4 = false;    

    //sorteia 100 letras de A-Z, e distribui entre os botoes
    function sortLetter() {
          var text = "";
          var possible = "abcçdefghijklmnopqrstuvwxyz";
          for (var i = 0; i < 100; i++) {
            text += '<div style="width: 10%; padding:0px;float:left; text-align: center;"><button onclick="selectButton(this);" style="text-align:center;  display:inline-block; padding:5px; margin:0px 0;  text-transform:uppercase; ">' + possible.charAt(Math.floor(Math.random() * possible.length)) + '</button></div>';  
          }
          $("#game").html(text);
          $("#game").append('<div class="clear"></div>');
          insertWords();
    }

    //insere as letras que contem as palavras nas posicoes corretas
    function insertWords() {            
            var finalPosition = [];
            $( correctLetters).each(function(index,value) {
                totalWords = totalWords + 1;                
                $( correctWordsPositions[index]).each(function(pos,val) {
                  //console.log (pos,val);
                  $( "#game" ).find( "button" ).eq(val).html(correctLetters[index][pos]);
                }); 
            });        
            //console.log ("O total de palavras deste jogo é: " + totalWords);
            $("#resetBtn").fadeIn();
            $("#hold-search").fadeIn();
    }    


    function selectButton(obj) {

        $(obj).toggleClass( "selected");
            $(obj).prop("disabled",true);
            $(obj).css("background","#F5A623");
            word += $(obj).html();
            //console.log (word);   
            validateWord (word);     
    }

    function validateWord(word) {                
            var str = word;
            var n = str.indexOf(word);
            //console.log (n);     

            $( words ).each(function( index, value ) {
              //console.log( index + ": " + value );
              if ( value == "joao" || "matheus" || "thiago" || "clara" ) {                                
                    str = word;
                    n = str.indexOf(word);
              }
            });        

            if ( n > -1 && word == "joao") {
                //console.log ("Voce acertou joao");
                enableWord (1);
                word1 = true;
                word = "";  

            }

            else if ( n > -1 && word == "matheus") {
                //console.log ("Voce acertou matheus");
                enableWord (2);
                word2 = true;
                word = "";  
            }

             else if ( n > -1 && word == "thiago") {
                //console.log ("Voce acertou thiago");
                enableWord (3);
                word3 = true;
                word = "";  
            }

             else if ( n > -1 && word == "clara") {
                //console.log ("Voce acertou thiago");
                enableWord (4);
                word4 = true;
                word = "";  
            }            

            else {
                //console.log("Nada encontrado!");
            }

            verifyWordsByPosition();
        
    }

    function enableWord (number) {
            //zerando novamente
            
        
            if (number == 1) { 
                console.log ("habilite a palavra 1");                
                $(correctWordsPositions[0]).each(function(index,value) { 
                    $( "#game" ).find( "button" ).eq(value).css("background","LawnGreen");
                    $( "#game" ).find( "button" ).eq(value).addClass("finished");
                });
                //console.log(wordsFound);
                
            }

            else if (number == 2) {
                console.log ("habilite a palavra 2");            
                $(correctWordsPositions[1]).each(function(index,value) { 
                    $( "#game" ).find( "button" ).eq(value).css("background","LawnGreen");
                    $( "#game" ).find( "button" ).eq(value).addClass("finished");
                });
                
            }
                
            else if (number == 3) {
                console.log ("habilite a palavra 3");
                $(correctWordsPositions[2]).each(function(index,value) { 
                    $( "#game" ).find( "button" ).eq(value).css("background","LawnGreen");
                    $( "#game" ).find( "button" ).eq(value).addClass("finished");
                });
                

            }

            else if (number == 4) {
                console.log ("habilite a palavra 4");
                $(correctWordsPositions[3]).each(function(index,value) { 
                    $( "#game" ).find( "button" ).eq(value).css("background","LawnGreen");
                    $( "#game" ).find( "button" ).eq(value).addClass("finished");
                });
                

            }            

    }


    function reset() {
        $( "button" ).each(function(  ) {
            if (!$(this).hasClass("finished")) {
                $(this).prop("disabled",false);    
                $(this).css("background","none");
            }
        });     
       word = "";        
    }   

   function search() {
        var wordText = $("#search").val();
        wordText = wordText.toLowerCase();
        validateWord(wordText);
    }    


    function verifyWordsByPosition() {

        var totalWords = 0;
        var totalWordsChecked = 0;      

        $(correctWordsPositions[0]).each(function(  index,value ) {
            totalWords = totalWords + 1;
            if ( $( "#game" ).find( "button" ).eq(value).hasClass("selected")) {
                totalWordsChecked = totalWordsChecked +1                
            }        
        });         

        if (totalWordsChecked == totalWords) {
                console.log ("Voce acertou joao");
                enableWord (1);
                word1 = true; 
                word = "";               
        }


        var totalWordsTwo = 0;
        var totalWordsCheckedTwo = 0;      

        $(correctWordsPositions[1]).each(function(  index,value ) {
            totalWordsTwo = totalWordsTwo + 1;
            if ( $( "#game" ).find( "button" ).eq(value).hasClass("selected")) {
                totalWordsCheckedTwo = totalWordsCheckedTwo +1                
            }        
        });         

        if (totalWordsTwo == totalWordsCheckedTwo) {
                console.log ("Voce acertou matheus");
                enableWord (2);      
                word2 = true;  
                word = "";        
        }


        var totalWordsThree = 0;
        var totalWordsCheckedThree = 0;      

        $(correctWordsPositions[2]).each(function(  index,value ) {
            totalWordsThree = totalWordsThree + 1;
            if ( $( "#game" ).find( "button" ).eq(value).hasClass("selected")) {
                totalWordsCheckedThree = totalWordsCheckedThree +1                
            }        
        });         

        if (totalWordsCheckedThree == totalWordsThree) {
                console.log ("Voce acertou thiago");
                enableWord (3);  
                word3 = true;  
                word = "";            
        }  

        var totalWordsFour = 0;
        var totalWordsCheckedFour = 0;      

        $(correctWordsPositions[3]).each(function(  index,value ) {
            totalWordsFour = totalWordsFour + 1;
            if ( $( "#game" ).find( "button" ).eq(value).hasClass("selected")) {
                totalWordsCheckedFour = totalWordsCheckedFour +1                
            }        
        });         

        if (totalWordsCheckedFour == totalWordsFour) {
                console.log ("Voce acertou clara");
                enableWord (4);  
                word4 = true;  
                word = "";            
        }                

        endGame();
        
    }


    function endGame () {        
        if (word1 && word2 && word3 && word4 == true)  {
            //alert ("PARABENS! você encontrou todas as palavras");
            $('#myModalLabel').html("PARABENS! <br/> Você encontrou todas as palavras!");
            $(".modal-body").html("<ul><li>"+ words[0].toUpperCase() + "</li> <li>" + words[1].toUpperCase() + "</li> <li>" + words[2].toUpperCase() + "</li ><li>" + words[3].toUpperCase() + "</li></ul>");
            $(".new").css("display","block");
            $("#resetBtn").css("display","none");
            $('#myModal').modal("show");
            //console.log("PARABENS! você encontrou todas as palavras");
            $( "button" ).each(function(  ) {                
                    $(this).prop("disabled",false);                    
            });              
            word = "";
        }
    }


    function showAnswer() {
        enableWord (1);  enableWord (2);  enableWord (3); enableWord (4);
        return false;
    }

    function newGame() {
        location.reload();
    }    





